"""
POI推荐与预测模型
基于协同过滤、地理距离和时间模式的混合推荐系统
"""

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from collections import defaultdict, Counter
import warnings
warnings.filterwarnings('ignore')


class POIRecommender:
    """POI推荐系统"""
    
    def __init__(self, df, location_col='venueId'):
        """
        初始化推荐系统
        Args:
            df: 签到数据集
            location_col: 位置列名
        """
        self.df = df
        self.location_col = location_col
        self.user_location_matrix = None
        self.location_coords = None
        
        print("初始化POI推荐系统...")
        self._prepare_data()
        
    def _prepare_data(self):
        """准备推荐所需的数据结构"""
        # 构建用户-地点矩阵
        user_location_counts = self.df.groupby(['userId', self.location_col]).size().reset_index(name='count')
        self.user_location_matrix = user_location_counts.pivot(
            index='userId', 
            columns=self.location_col, 
            values='count'
        ).fillna(0)
        
        # 保存地点坐标
        self.location_coords = self.df.groupby(self.location_col)[['latitude', 'longitude']].first()
        
        print(f"用户数: {len(self.user_location_matrix)}")
        print(f"地点数: {len(self.user_location_matrix.columns)}")
    
    def _haversine_distance(self, lat1, lon1, lat2, lon2):
        """计算Haversine距离（公里）"""
        R = 6371
        lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
        c = 2 * np.arcsin(np.sqrt(a))
        return R * c
    
    def collaborative_filtering(self, user_id, n_recommendations=10):
        """
        基于协同过滤的推荐
        Args:
            user_id: 用户ID
            n_recommendations: 推荐数量
        Returns:
            list: 推荐的地点列表
        """
        if user_id not in self.user_location_matrix.index:
            print(f"用户 {user_id} 不在数据集中")
            return []
        
        # 计算用户相似度
        user_vector = self.user_location_matrix.loc[user_id].values.reshape(1, -1)
        similarities = cosine_similarity(user_vector, self.user_location_matrix.values)[0]
        
        # 找到最相似的用户（排除自己）
        similar_users_idx = np.argsort(similarities)[::-1][1:21]  # Top 20相似用户
        similar_users = self.user_location_matrix.index[similar_users_idx]
        
        # 获取用户已访问的地点
        visited_locations = set(self.user_location_matrix.columns[
            self.user_location_matrix.loc[user_id] > 0
        ])
        
        # 聚合相似用户的地点偏好
        location_scores = defaultdict(float)
        for sim_user, similarity in zip(similar_users, similarities[similar_users_idx]):
            if similarity > 0:
                sim_user_locations = self.user_location_matrix.loc[sim_user]
                for loc, count in sim_user_locations[sim_user_locations > 0].items():
                    if loc not in visited_locations:
                        location_scores[loc] += similarity * count
        
        # 排序并返回推荐
        recommendations = sorted(location_scores.items(), 
                               key=lambda x: x[1], reverse=True)[:n_recommendations]
        
        return [loc for loc, score in recommendations]
    
    def location_based_recommendation(self, user_id, n_recommendations=10, max_distance=5):
        """
        基于地理位置的推荐
        Args:
            user_id: 用户ID
            n_recommendations: 推荐数量
            max_distance: 最大距离（公里）
        Returns:
            list: 推荐的地点列表
        """
        if user_id not in self.user_location_matrix.index:
            print(f"用户 {user_id} 不在数据集中")
            return []
        
        # 获取用户历史访问地点
        user_data = self.df[self.df['userId'] == user_id]
        visited_locations = set(user_data[self.location_col].unique())
        
        # 计算用户活动中心
        center_lat = user_data['latitude'].mean()
        center_lon = user_data['longitude'].mean()
        
        # 找到附近的热门地点
        location_scores = []
        
        for loc in self.location_coords.index:
            if loc in visited_locations:
                continue
            
            loc_data = self.location_coords.loc[loc]
            distance = self._haversine_distance(
                center_lat, center_lon, 
                loc_data['latitude'], loc_data['longitude']
            )
            
            if distance <= max_distance:
                # 计算地点热度
                popularity = len(self.df[self.df[self.location_col] == loc])
                # 距离越近，热度越高，得分越高
                score = popularity / (1 + distance)
                location_scores.append((loc, score))
        
        # 排序并返回推荐
        recommendations = sorted(location_scores, 
                               key=lambda x: x[1], reverse=True)[:n_recommendations]
        
        return [loc for loc, score in recommendations]
    
    def temporal_recommendation(self, user_id, current_hour, current_day, n_recommendations=10):
        """
        基于时间模式的推荐
        Args:
            user_id: 用户ID
            current_hour: 当前小时 (0-23)
            current_day: 当前星期几 (0-6)
            n_recommendations: 推荐数量
        Returns:
            list: 推荐的地点列表
        """
        if user_id not in self.user_location_matrix.index:
            print(f"用户 {user_id} 不在数据集中")
            return []
        
        # 获取用户历史访问地点
        user_data = self.df[self.df['userId'] == user_id]
        visited_locations = set(user_data[self.location_col].unique())
        
        # 找到相似时间段的热门地点
        time_filtered = self.df[
            (self.df['hour'] >= current_hour - 2) & 
            (self.df['hour'] <= current_hour + 2) &
            (self.df['dayofweek'] == current_day)
        ]
        
        if len(time_filtered) == 0:
            time_filtered = self.df[
                (self.df['hour'] >= current_hour - 2) & 
                (self.df['hour'] <= current_hour + 2)
            ]
        
        # 统计地点热度
        location_counts = time_filtered[self.location_col].value_counts()
        
        recommendations = []
        for loc, count in location_counts.items():
            if loc not in visited_locations:
                recommendations.append(loc)
                if len(recommendations) >= n_recommendations:
                    break
        
        return recommendations
    
    def hybrid_recommendation(self, user_id, current_hour=12, current_day=0, 
                             n_recommendations=10, weights=None):
        """
        混合推荐系统
        Args:
            user_id: 用户ID
            current_hour: 当前小时
            current_day: 当前星期几
            n_recommendations: 推荐数量
            weights: 各算法权重 {'cf': 0.4, 'location': 0.4, 'temporal': 0.2}
        Returns:
            list: 推荐的地点列表及其得分
        """
        if weights is None:
            weights = {'cf': 0.4, 'location': 0.4, 'temporal': 0.2}
        
        # 获取各算法的推荐结果
        cf_recs = self.collaborative_filtering(user_id, n_recommendations=20)
        loc_recs = self.location_based_recommendation(user_id, n_recommendations=20)
        temp_recs = self.temporal_recommendation(user_id, current_hour, current_day, 
                                                n_recommendations=20)
        
        # 计算综合得分
        location_scores = defaultdict(float)
        
        for i, loc in enumerate(cf_recs):
            location_scores[loc] += weights['cf'] * (20 - i) / 20
        
        for i, loc in enumerate(loc_recs):
            location_scores[loc] += weights['location'] * (20 - i) / 20
        
        for i, loc in enumerate(temp_recs):
            location_scores[loc] += weights['temporal'] * (20 - i) / 20
        
        # 排序并返回推荐
        recommendations = sorted(location_scores.items(), 
                               key=lambda x: x[1], reverse=True)[:n_recommendations]
        
        return recommendations
    
    def predict_next_location(self, user_id, n_predictions=5):
        """
        预测用户下一个可能访问的地点
        Args:
            user_id: 用户ID
            n_predictions: 预测数量
        Returns:
            list: 预测的地点列表
        """
        user_data = self.df[self.df['userId'] == user_id].sort_values('timestamp')
        
        if len(user_data) < 2:
            print(f"用户 {user_id} 的历史数据不足")
            return []
        
        # 分析用户的访问序列模式
        sequence = user_data[self.location_col].tolist()
        
        # 使用马尔可夫链预测
        transitions = defaultdict(Counter)
        for i in range(len(sequence) - 1):
            current = sequence[i]
            next_loc = sequence[i + 1]
            transitions[current][next_loc] += 1
        
        # 获取用户最近访问的地点
        last_location = sequence[-1]
        
        if last_location in transitions:
            # 基于转移概率预测
            next_locations = transitions[last_location].most_common(n_predictions)
            return [loc for loc, count in next_locations]
        else:
            # 回退到协同过滤
            return self.collaborative_filtering(user_id, n_recommendations=n_predictions)
    
    def evaluate_recommendations(self, test_user_ids=None, n_recommendations=10):
        """
        评估推荐系统性能
        Args:
            test_user_ids: 测试用户ID列表
            n_recommendations: 推荐数量
        Returns:
            dict: 评估指标
        """
        if test_user_ids is None:
            # 随机选择测试用户
            all_users = list(self.user_location_matrix.index)
            test_user_ids = np.random.choice(all_users, 
                                            min(100, len(all_users)), 
                                            replace=False)
        
        print(f"评估推荐系统 ({len(test_user_ids)} 个测试用户)...")
        
        precisions = []
        recalls = []
        
        for user_id in test_user_ids:
            # 获取用户的历史访问地点
            user_locations = set(self.user_location_matrix.columns[
                self.user_location_matrix.loc[user_id] > 0
            ])
            
            if len(user_locations) < 5:
                continue
            
            # 隐藏部分地点作为测试集
            test_size = max(1, len(user_locations) // 5)
            test_locations = set(np.random.choice(list(user_locations), 
                                                 test_size, replace=False))
            
            # 临时移除测试地点
            temp_matrix = self.user_location_matrix.copy()
            for loc in test_locations:
                temp_matrix.loc[user_id, loc] = 0
            
            # 生成推荐
            old_matrix = self.user_location_matrix
            self.user_location_matrix = temp_matrix
            
            try:
                recommendations = self.collaborative_filtering(user_id, n_recommendations)
                
                # 计算准确率和召回率
                hits = len(set(recommendations).intersection(test_locations))
                precision = hits / len(recommendations) if len(recommendations) > 0 else 0
                recall = hits / len(test_locations) if len(test_locations) > 0 else 0
                
                precisions.append(precision)
                recalls.append(recall)
            except:
                pass
            finally:
                self.user_location_matrix = old_matrix
        
        avg_precision = np.mean(precisions) if precisions else 0
        avg_recall = np.mean(recalls) if recalls else 0
        f1_score = 2 * avg_precision * avg_recall / (avg_precision + avg_recall) if (avg_precision + avg_recall) > 0 else 0
        
        results = {
            'precision': avg_precision,
            'recall': avg_recall,
            'f1_score': f1_score,
            'n_users': len(precisions)
        }
        
        print(f"\n评估结果:")
        print(f"  准确率 (Precision): {avg_precision:.4f}")
        print(f"  召回率 (Recall): {avg_recall:.4f}")
        print(f"  F1分数: {f1_score:.4f}")
        
        return results


if __name__ == '__main__':
    # 测试代码
    from data_loader import DataLoader
    
    loader = DataLoader(data_dir='../data')
    
    # 加载NYC数据（使用子集以加快测试）
    print("加载数据...")
    nyc_data = loader.load_foursquare_data('NYC')
    
    # 使用子集进行测试
    sample_data = nyc_data.head(50000)
    
    # 创建推荐系统
    recommender = POIRecommender(sample_data)
    
    # 测试推荐
    test_user = sample_data['userId'].iloc[0]
    print(f"\n为用户 {test_user} 生成推荐:")
    
    recs = recommender.hybrid_recommendation(test_user, n_recommendations=5)
    for i, (loc, score) in enumerate(recs, 1):
        print(f"  {i}. {loc} (得分: {score:.4f})")
