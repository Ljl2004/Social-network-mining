"""
POI数据可视化模块
实现用户签到分布、时空模式、社区分析的可视化
"""

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from matplotlib.patches import Circle
import matplotlib.font_manager as fm
import warnings
warnings.filterwarnings('ignore')


def get_chinese_font():
    """
    自动查找系统中可用的中文字体
    Returns:
        str: 可用的中文字体名称
    """
    # 常见中文字体列表（按优先级排序，macOS 系统优先使用 Hiragino Sans GB）
    chinese_fonts = [
        'Hiragino Sans GB',      # macOS 中文字体（最常见）
        'PingFang SC',           # macOS 默认中文字体
        'Songti SC',             # macOS 中文字体
        'STHeiti',               # macOS 华文黑体
        'Microsoft YaHei',       # Windows 微软雅黑
        'SimHei',                # Windows 黑体
        'SimSun',                # Windows 宋体
        'WenQuanYi Micro Hei',   # Linux 文泉驿微米黑
        'Noto Sans CJK SC',      # Linux Noto字体
        'Arial Unicode MS',      # 通用Unicode字体
    ]
    
    # 获取系统所有可用字体
    available_fonts = [f.name for f in fm.fontManager.ttflist]
    
    # 查找第一个可用的中文字体
    for font in chinese_fonts:
        if font in available_fonts:
            print(f"使用中文字体: {font}")
            return font
    
    # 如果没找到，返回默认字体
    print("警告: 未找到推荐的中文字体，使用系统默认字体")
    return 'sans-serif'


# 设置字体（自动检测中文字体）
chinese_font = get_chinese_font()
plt.rcParams['font.sans-serif'] = [chinese_font, 'Arial', 'DejaVu Sans']
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['axes.unicode_minus'] = False
# 确保所有文本元素都使用中文字体
plt.rcParams['font.serif'] = [chinese_font]
plt.rcParams['font.monospace'] = [chinese_font]

sns.set_style("whitegrid")

# 默认字号配置
DEFAULT_FONT_SIZES = {
    'title': 18,        # 标题字号
    'label': 16,        # 轴标签字号
    'tick': 16,         # 轴刻度字号
    'legend': 16,       # 图例字号
    'text': 16          # 其他文字字号
}


class POIVisualizer:
    """POI数据可视化类"""
    
    def __init__(self, output_dir='../figures', font_sizes=None):
        """
        初始化可视化器
        Args:
            output_dir: 图片输出目录
            font_sizes: 字号配置字典，可选键: 'title', 'label', 'tick', 'legend', 'text'
        """
        import os
        from matplotlib.font_manager import FontProperties
        
        # 如果是相对路径，转换为绝对路径
        if not os.path.isabs(output_dir):
            current_dir = os.path.dirname(os.path.abspath(__file__))
            self.output_dir = os.path.join(current_dir, output_dir)
        else:
            self.output_dir = output_dir
            
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        
        # 设置字号（使用默认值或自定义值）
        self.font_sizes = DEFAULT_FONT_SIZES.copy()
        if font_sizes:
            self.font_sizes.update(font_sizes)
        
        # 创建字体属性对象，确保中文正确显示
        self.font_prop = FontProperties(family=chinese_font, size=self.font_sizes['text'])
        self.font_prop_title = FontProperties(family=chinese_font, size=self.font_sizes['title'], weight='bold')
        self.font_prop_label = FontProperties(family=chinese_font, size=self.font_sizes['label'])
        self.font_prop_tick = FontProperties(family=chinese_font, size=self.font_sizes['tick'])
        self.font_prop_legend = FontProperties(family=chinese_font, size=self.font_sizes['legend'])
    
    def plot_user_checkins_map(self, df, user_id, location_col='venueId', 
                               title=None, save_name=None):
        """
        绘制用户签到地点分布图
        Args:
            df: 数据集
            user_id: 用户ID
            location_col: 位置列名
            title: 图表标题
            save_name: 保存文件名
        """
        user_data = df[df['userId'] == user_id]
        
        if len(user_data) == 0:
            print(f"用户 {user_id} 没有签到记录")
            return
        
        fig, ax = plt.subplots(figsize=(12, 8))
        
        # 绘制所有签到点
        scatter = ax.scatter(user_data['longitude'], user_data['latitude'], 
                           c=user_data['hour'], cmap='viridis', 
                           alpha=0.6, s=50, edgecolors='black', linewidth=0.5)
        
        # 标记最常访问的地点
        location_counts = user_data[location_col].value_counts()
        if len(location_counts) > 0:
            top_location = location_counts.index[0]
            top_loc_data = user_data[user_data[location_col] == top_location].iloc[0]
            ax.scatter(top_loc_data['longitude'], top_loc_data['latitude'], 
                      c='red', s=300, marker='*', 
                      edgecolors='black', linewidth=2, 
                      label=f'最常访问 ({location_counts.iloc[0]}次)')
        
        cbar = plt.colorbar(scatter, ax=ax, label='Check-in Hour')
        cbar.ax.tick_params(labelsize=self.font_sizes['tick'])
        cbar.set_label('Check-in Hour', fontsize=self.font_sizes['label'])
        
        ax.set_xlabel('Longitude', fontsize=self.font_sizes['label'])
        ax.set_ylabel('Latitude', fontsize=self.font_sizes['label'])
        ax.tick_params(axis='both', labelsize=self.font_sizes['tick'])
        
        if title:
            ax.set_title(title, fontproperties=self.font_prop_title)
        else:
            ax.set_title(f'User {user_id} Check-in Distribution (Total: {len(user_data)})', 
                        fontsize=self.font_sizes['title'], fontweight='bold')
        
        legend = ax.legend(fontsize=self.font_sizes['legend'])
        for text in legend.get_texts():
            text.set_fontproperties(self.font_prop_legend)
        ax.grid(True, alpha=0.3)
        
        if save_name:
            plt.savefig(f'{self.output_dir}/{save_name}', dpi=300, bbox_inches='tight')
            print(f"图表已保存: {self.output_dir}/{save_name}")
        
        plt.tight_layout()
        plt.show()
    
    def plot_temporal_patterns(self, df, save_name=None):
        """
        绘制时间模式分析图
        Args:
            df: 数据集
            save_name: 保存文件名
        """
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        
        # 1. 每小时签到分布
        hourly_checkins = df['hour'].value_counts().sort_index()
        axes[0, 0].bar(hourly_checkins.index, hourly_checkins.values, 
                      color='steelblue', alpha=0.7)
        axes[0, 0].set_xlabel('Hour of Day', fontsize=self.font_sizes['label'])
        axes[0, 0].set_ylabel('Check-in Count', fontsize=self.font_sizes['label'])
        axes[0, 0].set_title('Hourly Check-in Distribution', fontsize=self.font_sizes['title'], fontweight='bold')
        axes[0, 0].tick_params(axis='both', labelsize=self.font_sizes['tick'])
        axes[0, 0].grid(True, alpha=0.3)
        
        # 2. 每周各天签到分布
        day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        daily_checkins = df['dayofweek'].value_counts().sort_index()
        axes[0, 1].bar(range(len(daily_checkins)), daily_checkins.values, 
                      color='coral', alpha=0.7)
        axes[0, 1].set_xticks(range(7))
        axes[0, 1].set_xticklabels(day_names, rotation=45, fontsize=self.font_sizes['tick'])
        axes[0, 1].set_xlabel('Day of Week', fontsize=self.font_sizes['label'])
        axes[0, 1].set_ylabel('Check-in Count', fontsize=self.font_sizes['label'])
        axes[0, 1].set_title('Weekly Check-in Distribution', fontsize=self.font_sizes['title'], fontweight='bold')
        axes[0, 1].tick_params(axis='y', labelsize=self.font_sizes['tick'])
        axes[0, 1].grid(True, alpha=0.3)
        
        # 3. 签到热力图（小时 x 星期）
        heatmap_data = df.groupby(['dayofweek', 'hour']).size().unstack(fill_value=0)
        sns.heatmap(heatmap_data, cmap='YlOrRd', ax=axes[1, 0], 
                   cbar_kws={'label': 'Count'}, 
                   annot=False)
        axes[1, 0].set_xlabel('Hour', fontsize=self.font_sizes['label'])
        axes[1, 0].set_ylabel('Day of Week', fontsize=self.font_sizes['label'])
        axes[1, 0].set_yticklabels(day_names, rotation=0, fontsize=self.font_sizes['tick'])
        axes[1, 0].set_xticklabels(axes[1, 0].get_xticklabels(), fontsize=self.font_sizes['tick'])
        axes[1, 0].set_title('Check-in Heatmap (Hour x Day)', fontsize=self.font_sizes['title'], fontweight='bold')
        cbar = axes[1, 0].collections[0].colorbar
        cbar.ax.tick_params(labelsize=self.font_sizes['tick'])
        
        # 4. 每日签到趋势
        daily_trend = df.groupby('date').size()
        axes[1, 1].plot(range(len(daily_trend)), daily_trend.values, 
                       color='green', linewidth=2, alpha=0.7)
        axes[1, 1].fill_between(range(len(daily_trend)), daily_trend.values, 
                               alpha=0.3, color='green')
        axes[1, 1].set_xlabel('Days', fontsize=self.font_sizes['label'])
        axes[1, 1].set_ylabel('Check-in Count', fontsize=self.font_sizes['label'])
        axes[1, 1].set_title('Daily Check-in Trend', fontsize=self.font_sizes['title'], fontweight='bold')
        axes[1, 1].tick_params(axis='both', labelsize=self.font_sizes['tick'])
        axes[1, 1].grid(True, alpha=0.3)
        
        plt.tight_layout(pad=3.0, h_pad=3.0, w_pad=3.0)
        
        if save_name:
            plt.savefig(f'{self.output_dir}/{save_name}', dpi=300, bbox_inches='tight')
            print(f"图表已保存: {self.output_dir}/{save_name}")
        
        plt.tight_layout()
        plt.show()
    
    def plot_location_popularity(self, df, top_n=20, location_col='venueId', save_name=None):
        """
        绘制地点热度分布
        Args:
            df: 数据集
            top_n: 显示前N个热门地点
            location_col: 位置列名
            save_name: 保存文件名
        """
        location_counts = df[location_col].value_counts().head(top_n)
        
        fig, ax = plt.subplots(figsize=(12, 6))
        
        bars = ax.barh(range(len(location_counts)), location_counts.values, 
                       color='teal', alpha=0.7)
        
        # 渐变色
        colors = plt.cm.viridis(np.linspace(0.3, 0.9, len(bars)))
        for bar, color in zip(bars, colors):
            bar.set_color(color)
        
        ax.set_yticks(range(len(location_counts)))
        ax.set_yticklabels([f'POI-{lid[:8]}...' for lid in location_counts.index], 
                          fontsize=self.font_sizes['tick'])
        ax.set_xlabel('Visit Count', fontsize=self.font_sizes['label'])
        ax.set_title(f'Top {top_n} Popular Locations', fontsize=self.font_sizes['title'], fontweight='bold')
        ax.tick_params(axis='x', labelsize=self.font_sizes['tick'])
        ax.invert_yaxis()
        ax.grid(True, alpha=0.3, axis='x')
        
        # 添加数值标签
        for i, (idx, val) in enumerate(location_counts.items()):
            ax.text(val + max(location_counts.values)*0.01, i, str(val), 
                   va='center', fontsize=self.font_sizes['text'])
        
        if save_name:
            plt.savefig(f'{self.output_dir}/{save_name}', dpi=300, bbox_inches='tight')
            print(f"图表已保存: {self.output_dir}/{save_name}")
        
        plt.tight_layout()
        plt.show()
    
    def plot_spatial_distribution(self, df, sample_size=5000, location_col='venueId', 
                                  title=None, save_name=None):
        """
        绘制地理空间分布图
        Args:
            df: 数据集
            sample_size: 采样大小（避免绘制过多点）
            location_col: 位置列名
            title: 图表标题
            save_name: 保存文件名
        """
        if len(df) > sample_size:
            plot_df = df.sample(n=sample_size, random_state=42)
        else:
            plot_df = df
        
        fig, ax = plt.subplots(figsize=(14, 10))
        
        # 计算每个地点的访问频率
        location_freq = df[location_col].value_counts()
        plot_df['visit_freq'] = plot_df[location_col].map(location_freq)
        
        scatter = ax.scatter(plot_df['longitude'], plot_df['latitude'], 
                           c=np.log1p(plot_df['visit_freq']), 
                           cmap='hot', alpha=0.6, s=30, 
                           edgecolors='black', linewidth=0.3)
        
        cbar = plt.colorbar(scatter, ax=ax, label='Visit Frequency (log)')
        cbar.ax.tick_params(labelsize=self.font_sizes['tick'])
        cbar.set_label('Visit Frequency (log)', fontsize=self.font_sizes['label'])
        
        ax.set_xlabel('Longitude', fontsize=self.font_sizes['label'])
        ax.set_ylabel('Latitude', fontsize=self.font_sizes['label'])
        ax.tick_params(axis='both', labelsize=self.font_sizes['tick'])
        
        if title:
            ax.set_title(title, fontproperties=self.font_prop_title)
        else:
            ax.set_title(f'POI Spatial Distribution (Sample: {len(plot_df)} check-ins)', 
                        fontsize=self.font_sizes['title'], fontweight='bold')
        
        ax.grid(True, alpha=0.3)
        
        if save_name:
            plt.savefig(f'{self.output_dir}/{save_name}', dpi=300, bbox_inches='tight')
            print(f"图表已保存: {self.output_dir}/{save_name}")
        
        plt.tight_layout()
        plt.show()
    
    def plot_user_activity_distribution(self, user_features, save_name=None):
        """
        绘制用户活跃度分布
        Args:
            user_features: 用户特征DataFrame
            save_name: 保存文件名
        """
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        
        # 1. 签到次数分布
        axes[0, 0].hist(user_features['checkin_count'], bins=50, 
                       color='skyblue', alpha=0.7, edgecolor='black')
        axes[0, 0].set_xlabel('Check-in Count', fontsize=self.font_sizes['label'])
        axes[0, 0].set_ylabel('Number of Users', fontsize=self.font_sizes['label'])
        axes[0, 0].set_title('User Check-in Count Distribution', fontsize=self.font_sizes['title'], fontweight='bold')
        axes[0, 0].tick_params(axis='both', labelsize=self.font_sizes['tick'])
        axes[0, 0].set_yscale('log')
        axes[0, 0].grid(True, alpha=0.3)
        
        # 2. 唯一地点数分布
        axes[0, 1].hist(user_features['unique_locations'], bins=50, 
                       color='lightcoral', alpha=0.7, edgecolor='black')
        axes[0, 1].set_xlabel('Unique Locations Visited', fontsize=self.font_sizes['label'])
        axes[0, 1].set_ylabel('Number of Users', fontsize=self.font_sizes['label'])
        axes[0, 1].set_title('User Exploration Diversity', fontsize=self.font_sizes['title'], fontweight='bold')
        axes[0, 1].tick_params(axis='both', labelsize=self.font_sizes['tick'])
        axes[0, 1].set_yscale('log')
        axes[0, 1].grid(True, alpha=0.3)
        
        # 3. 签到次数 vs 唯一地点数
        axes[1, 0].scatter(user_features['checkin_count'], 
                          user_features['unique_locations'], 
                          alpha=0.5, s=20, color='purple')
        axes[1, 0].set_xlabel('Check-in Count', fontsize=self.font_sizes['label'])
        axes[1, 0].set_ylabel('Unique Locations', fontsize=self.font_sizes['label'])
        axes[1, 0].set_title('User Activity vs Exploration', fontsize=self.font_sizes['title'], fontweight='bold')
        axes[1, 0].tick_params(axis='both', labelsize=self.font_sizes['tick'])
        axes[1, 0].set_xscale('log')
        axes[1, 0].set_yscale('log')
        axes[1, 0].grid(True, alpha=0.3)
        
        # 4. 最爱签到时间分布
        axes[1, 1].hist(user_features['favorite_hour'], bins=24, 
                       color='orange', alpha=0.7, edgecolor='black')
        axes[1, 1].set_xlabel('Favorite Check-in Hour', fontsize=self.font_sizes['label'])
        axes[1, 1].set_ylabel('Number of Users', fontsize=self.font_sizes['label'])
        axes[1, 1].set_title('User Favorite Check-in Time', fontsize=self.font_sizes['title'], fontweight='bold')
        axes[1, 1].set_xticks(range(0, 24, 2))
        axes[1, 1].tick_params(axis='both', labelsize=self.font_sizes['tick'])
        axes[1, 1].grid(True, alpha=0.3)
        
        plt.tight_layout(pad=3.0, h_pad=3.0, w_pad=3.0)
        
        if save_name:
            plt.savefig(f'{self.output_dir}/{save_name}', dpi=300, bbox_inches='tight')
            print(f"图表已保存: {self.output_dir}/{save_name}")
        
        plt.tight_layout()
        plt.show()
    
    def plot_community_analysis(self, df, location_col='venueId', 
                               n_locations=10, save_name=None):
        """
        绘制社区共现分析（基于共同访问的地点）
        Args:
            df: 数据集
            location_col: 位置列名
            n_locations: 分析的热门地点数量
            save_name: 保存文件名
        """
        # 找出最热门的地点
        top_locations = df[location_col].value_counts().head(n_locations).index
        
        # 构建共现矩阵
        co_occurrence = np.zeros((n_locations, n_locations))
        
        for i, loc1 in enumerate(top_locations):
            users1 = set(df[df[location_col] == loc1]['userId'])
            for j, loc2 in enumerate(top_locations):
                if i != j:
                    users2 = set(df[df[location_col] == loc2]['userId'])
                    co_occurrence[i, j] = len(users1.intersection(users2))
        
        fig, ax = plt.subplots(figsize=(12, 10))
        
        im = ax.imshow(co_occurrence, cmap='YlOrRd', aspect='auto')
        
        # 设置刻度标签
        location_labels = [f'POI-{lid[:6]}' for lid in top_locations]
        ax.set_xticks(range(n_locations))
        ax.set_yticks(range(n_locations))
        ax.set_xticklabels(location_labels, rotation=45, ha='right', 
                          fontsize=self.font_sizes['tick'])
        ax.set_yticklabels(location_labels, fontsize=self.font_sizes['tick'])
        
        # 添加数值
        for i in range(n_locations):
            for j in range(n_locations):
                if co_occurrence[i, j] > 0:
                    text = ax.text(j, i, int(co_occurrence[i, j]),
                                 ha="center", va="center", color="black", 
                                 fontsize=self.font_sizes['text'])
        
        cbar = plt.colorbar(im, ax=ax, label='Common Visitors')
        cbar.ax.tick_params(labelsize=self.font_sizes['tick'])
        cbar.set_label('Common Visitors', fontsize=self.font_sizes['label'])
        
        ax.set_title(f'Top {n_locations} Location Co-occurrence Analysis', 
                    fontsize=self.font_sizes['title'], fontweight='bold')
        
        if save_name:
            plt.savefig(f'{self.output_dir}/{save_name}', dpi=300, bbox_inches='tight')
            print(f"图表已保存: {self.output_dir}/{save_name}")
        
        plt.tight_layout()
        plt.show()


if __name__ == '__main__':
    # 测试代码
    from data_loader import DataLoader
    
    loader = DataLoader(data_dir='../data')
    visualizer = POIVisualizer(output_dir='../figures')
    
    # 加载数据
    nyc_data = loader.load_foursquare_data('NYC')
    
    # 可视化演示
    print("\n生成可视化图表...")
    visualizer.plot_temporal_patterns(nyc_data.head(10000), 
                                     save_name='temporal_patterns.png')
