"""
查看系统可用的中文字体
帮助用户了解本机安装了哪些中文字体
"""

import matplotlib.font_manager as fm


def list_chinese_fonts():
    """列出系统中所有可用的中文字体"""
    
    print("=" * 70)
    print("  系统中文字体检测工具")
    print("=" * 70)
    
    # 获取所有字体
    all_fonts = [f.name for f in fm.fontManager.ttflist]
    
    # 中文字体关键词
    chinese_keywords = [
        'SC', 'GB', 'Hei', 'Song', 'Kai', 'Fang',
        'YaHei', 'SimHei', 'SimSun', 'SimKai',
        'PingFang', 'Hiragino', 'STHeiti', 'STKaiti', 'STSong',
        'WenQuanYi', 'Noto', 'CJK', 'Microsoft', 'Arial Unicode',
        '黑体', '宋体', '楷体', '仿宋'
    ]
    
    # 筛选中文字体
    chinese_fonts = []
    for font in all_fonts:
        if any(keyword.lower() in font.lower() for keyword in chinese_keywords):
            chinese_fonts.append(font)
    
    # 去重并排序
    chinese_fonts = sorted(set(chinese_fonts))
    
    print(f"\n找到 {len(chinese_fonts)} 个中文相关字体:\n")
    
    # 推荐的字体列表
    recommended_fonts = [
        'PingFang SC',
        'Hiragino Sans GB',
        'STHeiti',
        'Microsoft YaHei',
        'SimHei',
        'SimSun',
        'WenQuanYi Micro Hei',
        'Noto Sans CJK SC',
        'Arial Unicode MS',
    ]
    
    # 显示推荐字体的可用性
    print("【推荐字体】")
    print("-" * 70)
    available_recommended = []
    for font in recommended_fonts:
        if font in chinese_fonts:
            print(f"  ✅ {font}")
            available_recommended.append(font)
        else:
            print(f"  ❌ {font} (未安装)")
    
    if available_recommended:
        print(f"\n✨ 可视化系统将使用: {available_recommended[0]}")
    else:
        print("\n⚠️  警告: 未找到推荐的中文字体，可能出现乱码")
    
    # 显示所有其他中文字体
    other_fonts = [f for f in chinese_fonts if f not in recommended_fonts]
    
    if other_fonts:
        print(f"\n【其他可用中文字体】({len(other_fonts)}个)")
        print("-" * 70)
        for i, font in enumerate(other_fonts, 1):
            print(f"  {i:2d}. {font}")
    
    # 显示字体文件路径示例
    print("\n【字体文件路径示例】")
    print("-" * 70)
    if available_recommended:
        # 找到第一个推荐字体的路径
        font_name = available_recommended[0]
        for font_file in fm.fontManager.ttflist:
            if font_file.name == font_name:
                print(f"  字体名称: {font_file.name}")
                print(f"  文件路径: {font_file.fname}")
                break
    
    print("\n" + "=" * 70)
    print("提示: 如需安装新字体，请访问系统字体管理工具")
    print("  • macOS: 字体册 (Font Book)")
    print("  • Windows: 控制面板 → 字体")
    print("  • Linux: 字体管理器或手动安装到 ~/.fonts/")
    print("=" * 70)


def test_font_rendering():
    """测试字体渲染效果"""
    import matplotlib.pyplot as plt
    
    print("\n正在生成字体测试图表...")
    
    # 获取可用的中文字体
    all_fonts = [f.name for f in fm.fontManager.ttflist]
    recommended = [
        'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', 
        'SimHei', 'Arial Unicode MS'
    ]
    
    available = [f for f in recommended if f in all_fonts]
    
    if not available:
        print("错误: 没有找到可用的中文字体")
        return
    
    # 创建测试图表
    fig, axes = plt.subplots(len(available), 1, figsize=(10, 2*len(available)))
    if len(available) == 1:
        axes = [axes]
    
    test_text = "中文字体测试 - 1234567890 - ABCabc"
    
    for ax, font in zip(axes, available):
        ax.text(0.5, 0.5, test_text, 
               fontsize=20, 
               ha='center', va='center',
               fontproperties=fm.FontProperties(family=font))
        ax.set_title(f"字体: {font}", fontsize=12)
        ax.axis('off')
    
    plt.tight_layout()
    plt.savefig('font_test.png', dpi=150, bbox_inches='tight')
    print("✓ 字体测试图表已保存: font_test.png")
    plt.close()


if __name__ == '__main__':
    list_chinese_fonts()
    
    # 询问是否生成测试图表
    try:
        choice = input("\n是否生成字体测试图表? (y/n): ")
        if choice.lower() == 'y':
            test_font_rendering()
    except:
        pass
