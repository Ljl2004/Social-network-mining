"""
数据加载和预处理模块
处理Foursquare (NYC/TKY) 和 Brightkite 数据集
"""

import pandas as pd
import numpy as np
from datetime import datetime
import os


class DataLoader:
    """数据加载器类"""
    
    def __init__(self, data_dir='../data'):
        """
        初始化数据加载器
        Args:
            data_dir: 数据文件目录
        """
        # 如果是相对路径，转换为绝对路径
        if not os.path.isabs(data_dir):
            # 获取当前文件所在目录
            current_dir = os.path.dirname(os.path.abspath(__file__))
            self.data_dir = os.path.join(current_dir, data_dir)
        else:
            self.data_dir = data_dir
        
    def load_foursquare_data(self, city='NYC'):
        """
        加载Foursquare数据集
        Args:
            city: 'NYC' 或 'TKY'
        Returns:
            DataFrame: 清洗后的数据
        """
        file_path = os.path.join(self.data_dir, f'dataset_TSMC2014_{city}.csv')
        print(f"加载 {city} 数据...")
        
        df = pd.read_csv(file_path)
        
        # 数据清洗
        df['timestamp'] = pd.to_datetime(df['utcTimestamp'])
        df['hour'] = df['timestamp'].dt.hour
        df['dayofweek'] = df['timestamp'].dt.dayofweek
        df['date'] = df['timestamp'].dt.date
        
        # 移除缺失值
        df = df.dropna(subset=['latitude', 'longitude', 'userId', 'venueId'])
        
        print(f"数据加载完成: {len(df)} 条记录")
        print(f"用户数: {df['userId'].nunique()}")
        print(f"POI数: {df['venueId'].nunique()}")
        
        return df
    
    def load_brightkite_data(self, sample_size=None):
        """
        加载Brightkite数据集
        Args:
            sample_size: 如果指定，只加载前N行数据（文件很大）
        Returns:
            DataFrame: 清洗后的数据
        """
        file_path = os.path.join(self.data_dir, 'loc-brightkite_totalCheckins.txt')
        print("加载 Brightkite 数据...")
        
        # Brightkite数据格式: user_id, check-in time, latitude, longitude, location_id
        columns = ['userId', 'timestamp_str', 'latitude', 'longitude', 'locationId']
        
        if sample_size:
            df = pd.read_csv(file_path, sep='\t', names=columns, 
                           nrows=sample_size, on_bad_lines='skip')
        else:
            df = pd.read_csv(file_path, sep='\t', names=columns, 
                           on_bad_lines='skip')
        
        # 数据清洗
        df['timestamp'] = pd.to_datetime(df['timestamp_str'])
        df['hour'] = df['timestamp'].dt.hour
        df['dayofweek'] = df['timestamp'].dt.dayofweek
        df['date'] = df['timestamp'].dt.date
        
        # 移除缺失值
        df = df.dropna(subset=['latitude', 'longitude', 'userId', 'locationId'])
        
        print(f"数据加载完成: {len(df)} 条记录")
        print(f"用户数: {df['userId'].nunique()}")
        print(f"POI数: {df['locationId'].nunique()}")
        
        return df
    
    def get_user_checkin_history(self, df, user_id, location_col='venueId'):
        """
        获取指定用户的签到历史
        Args:
            df: 数据集
            user_id: 用户ID
            location_col: 位置列名
        Returns:
            DataFrame: 用户的签到记录
        """
        user_data = df[df['userId'] == user_id].sort_values('timestamp')
        return user_data
    
    def get_location_visitors(self, df, location_id, location_col='venueId'):
        """
        获取指定地点的访问者列表
        Args:
            df: 数据集
            location_id: 地点ID
            location_col: 位置列名
        Returns:
            DataFrame: 该地点的访问记录
        """
        location_data = df[df[location_col] == location_id].sort_values('timestamp')
        return location_data
    
    def compute_user_features(self, df, location_col='venueId'):
        """
        计算用户特征
        Args:
            df: 数据集
            location_col: 位置列名
        Returns:
            DataFrame: 用户特征
        """
        print("计算用户特征...")
        
        user_features = df.groupby('userId').agg({
            location_col: 'count',  # 签到次数
            'latitude': ['mean', 'std'],  # 位置中心和分散度
            'longitude': ['mean', 'std'],
            'hour': lambda x: x.mode()[0] if len(x.mode()) > 0 else x.mean(),  # 最常签到时间
            'dayofweek': lambda x: x.mode()[0] if len(x.mode()) > 0 else x.mean()
        }).reset_index()
        
        user_features.columns = ['userId', 'checkin_count', 'lat_mean', 'lat_std', 
                                'lon_mean', 'lon_std', 'favorite_hour', 'favorite_day']
        
        # 计算每个用户访问的唯一地点数
        unique_locs = df.groupby('userId')[location_col].nunique().reset_index()
        unique_locs.columns = ['userId', 'unique_locations']
        user_features = user_features.merge(unique_locs, on='userId')
        
        return user_features
    
    def compute_location_features(self, df, location_col='venueId'):
        """
        计算地点特征
        Args:
            df: 数据集
            location_col: 位置列名
        Returns:
            DataFrame: 地点特征
        """
        print("计算地点特征...")
        
        location_features = df.groupby(location_col).agg({
            'userId': 'count',  # 访问次数
            'latitude': 'first',  # 位置
            'longitude': 'first',
        }).reset_index()
        
        location_features.columns = [location_col, 'visit_count', 'latitude', 'longitude']
        
        # 计算唯一访问者数
        unique_users = df.groupby(location_col)['userId'].nunique().reset_index()
        unique_users.columns = [location_col, 'unique_visitors']
        location_features = location_features.merge(unique_users, on=location_col)
        
        return location_features


def haversine_distance(lat1, lon1, lat2, lon2):
    """
    计算两点间的Haversine距离（公里）
    Args:
        lat1, lon1: 第一个点的纬度和经度
        lat2, lon2: 第二个点的纬度和经度
    Returns:
        float: 距离（公里）
    """
    R = 6371  # 地球半径（公里）
    
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    
    a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
    c = 2 * np.arcsin(np.sqrt(a))
    
    return R * c


if __name__ == '__main__':
    # 测试代码
    loader = DataLoader(data_dir='../data')
    
    # 加载NYC数据
    nyc_data = loader.load_foursquare_data('NYC')
    print("\nNYC数据预览:")
    print(nyc_data.head())
    
    # 计算用户特征
    user_features = loader.compute_user_features(nyc_data)
    print("\n用户特征:")
    print(user_features.head())
