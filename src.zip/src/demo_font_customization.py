"""
可视化字号自定义示例
演示如何设置不同的字号配置
"""

import sys
import os
sys.path.append(os.path.dirname(__file__))

from data_loader import DataLoader
from visualizer import POIVisualizer


def demo_font_customization():
    """演示字号自定义功能"""
    
    print("=" * 70)
    print("  POI可视化 - 字号自定义示例")
    print("=" * 70)
    
    # 加载数据
    print("\n加载数据...")
    loader = DataLoader(data_dir='../data')
    nyc_data = loader.load_foursquare_data('NYC')
    sample_data = nyc_data.head(10000)
    
    # 示例1: 使用默认字号（所有字号最小16）
    print("\n[示例1] 使用默认字号配置（最小字号16）")
    print("  - 标题: 18")
    print("  - 轴标签: 16")
    print("  - 轴刻度: 16")
    print("  - 图例: 16")
    print("  - 文字: 16")
    
    visualizer_default = POIVisualizer(output_dir='../figures')
    visualizer_default.plot_temporal_patterns(sample_data, 
                                             save_name='font_default.png')
    print("✓ 图表已生成: figures/font_default.png")
    
    # 示例2: 自定义字号（更大的字体用于演示）
    print("\n[示例2] 使用自定义字号配置")
    custom_fonts = {
        'title': 22,    # 标题字号
        'label': 18,    # 轴标签字号
        'tick': 16,     # 轴刻度字号
        'legend': 17,   # 图例字号
        'text': 16      # 其他文字字号
    }
    print(f"  - 标题: {custom_fonts['title']}")
    print(f"  - 轴标签: {custom_fonts['label']}")
    print(f"  - 轴刻度: {custom_fonts['tick']}")
    print(f"  - 图例: {custom_fonts['legend']}")
    print(f"  - 文字: {custom_fonts['text']}")
    
    visualizer_custom = POIVisualizer(output_dir='../figures', 
                                     font_sizes=custom_fonts)
    visualizer_custom.plot_spatial_distribution(sample_data, 
                                               sample_size=2000,
                                               title='NYC POI Spatial Distribution',
                                               save_name='font_custom.png')
    print("✓ 图表已生成: figures/font_custom.png")
    
    # 示例3: 部分自定义（只修改部分字号）
    print("\n[示例3] 部分自定义字号（只修改标题和标签）")
    partial_fonts = {
        'title': 24,    # 只修改标题
        'label': 20,    # 只修改轴标签
        # 其他使用默认值
    }
    print(f"  - 标题: {partial_fonts['title']}")
    print(f"  - 轴标签: {partial_fonts['label']}")
    print("  - 其他: 使用默认值")
    
    visualizer_partial = POIVisualizer(output_dir='../figures', 
                                      font_sizes=partial_fonts)
    visualizer_partial.plot_location_popularity(sample_data, 
                                               top_n=15,
                                               save_name='font_partial.png')
    print("✓ 图表已生成: figures/font_partial.png")
    
    print("\n" + "=" * 70)
    print("✨ 字号自定义演示完成！")
    print("\n所有可视化图表使用:")
    print("  • 字体: Helvetica/Arial (英文)")
    print("  • 最小字号: 16")
    print("  • 可自定义: 标题、标签、刻度、图例、文字")
    print("\n查看生成的图表: figures/font_*.png")
    print("=" * 70)


if __name__ == '__main__':
    demo_font_customization()
