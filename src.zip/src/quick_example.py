"""
简单使用示例 - 快速开始
展示如何使用POI分析系统的核心功能
"""

import sys
import os
sys.path.append(os.path.dirname(__file__))

from data_loader import DataLoader
from visualizer import POIVisualizer
from recommender import POIRecommender


def quick_start():
    """快速开始示例"""
    
    print("=" * 60)
    print("  POI分析系统 - 快速开始示例")
    print("=" * 60)
    
    # 1. 加载数据
    print("\n[1] 加载数据...")
    loader = DataLoader(data_dir='../data')
    nyc_data = loader.load_foursquare_data('NYC')
    print(f"✓ 加载了 {len(nyc_data):,} 条签到记录")
    
    # 2. 数据可视化示例
    print("\n[2] 生成可视化图表...")
    visualizer = POIVisualizer(output_dir='../figures')
    
    # 使用部分数据以加快速度
    sample_data = nyc_data.head(10000)
    
    # 时间模式分析
    visualizer.plot_temporal_patterns(sample_data, 
                                     save_name='example_temporal.png')
    print("✓ 时间模式图已生成")
    
    # 空间分布
    visualizer.plot_spatial_distribution(sample_data, 
                                        sample_size=2000,
                                        save_name='example_spatial.png')
    print("✓ 空间分布图已生成")
    
    # 3. POI推荐示例
    print("\n[3] POI推荐演示...")
    
    # 使用较小数据集进行演示
    sample_for_rec = nyc_data.head(50000)
    recommender = POIRecommender(sample_for_rec)
    
    # 选择一个活跃用户
    user_counts = sample_for_rec['userId'].value_counts()
    demo_user = user_counts.index[10]  # 第11活跃的用户
    
    print(f"\n为用户 {demo_user} 生成推荐:")
    
    # 混合推荐
    recommendations = recommender.hybrid_recommendation(
        demo_user, 
        current_hour=18,  # 下午6点
        current_day=4,     # 周五
        n_recommendations=5
    )
    
    print("\n推荐结果:")
    for i, (loc, score) in enumerate(recommendations, 1):
        loc_info = sample_for_rec[sample_for_rec['venueId'] == loc].iloc[0]
        print(f"  {i}. {loc_info['venueCategory']:30s} (得分: {score:.4f})")
    
    # 4. 下一地点预测
    print(f"\n[4] 预测用户下一个可能访问的地点:")
    next_locs = recommender.predict_next_location(demo_user, n_predictions=3)
    
    for i, loc in enumerate(next_locs, 1):
        if loc in sample_for_rec['venueId'].values:
            loc_info = sample_for_rec[sample_for_rec['venueId'] == loc].iloc[0]
            print(f"  {i}. {loc_info['venueCategory']}")
        else:
            print(f"  {i}. {loc}")
    
    print("\n" + "=" * 60)
    print("✨ 示例运行完成！")
    print("\n查看生成的图表: figures/example_*.png")
    print("=" * 60)


if __name__ == '__main__':
    quick_start()
